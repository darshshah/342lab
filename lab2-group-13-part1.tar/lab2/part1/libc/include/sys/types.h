/*
 * types.h: Defines typedefs used in libc
 *
 * Author: Mike Kasick <mkasick@andrew.cmu.edu>
 * Date:   Sun, 07 Oct 2007 01:38:48 -0400
 */

#ifndef SYS_TYPES_H
#define SYS_TYPES_H

#include <bits/types.h>

#endif /* SYS_TYPES_H */
