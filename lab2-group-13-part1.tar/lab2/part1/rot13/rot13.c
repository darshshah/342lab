/* 
 * rot13.c: ROT13 cipher test application
 *
 * Authors: Anish Parikh  <asp@andrew.cmu.edu>
 *          Darsh Shah    <darshs@andrew.cmu.edu>
 *          Subramanian Srisankaran <ssrisank@andrew.cmu.edu>
 *  Date:   11th Oct 1:30 pm
 */

#include<stdlib.h>
#include<errno.h>
int main(int argc, char **argv) {
   
   
    int x=0,y=0,i=0,j=0;
    char buf[100];    //Block size is 100
    for(i=1;i<argc;i++)
    {
        while(argv[i][j] !='\0')
        {    
            j++;
        }

        write(1, argv[i], j);
        j=0;
    }
    while(1) 			
    {
    if((x = read(0,buf,100)) == -1)  //return -1 if syscall error
    {
         return 1;
    }
    else
    {
    	if(x == 1)		// if 0 bytes are read (i.e. no input given)
	return 0;
	else
	{
	for(i=0;i<x;i++)     // cipher algorithm implementation
	{ 
	if((buf[i] >= 'N' && buf[i] <= 'Z')||(buf[i] >= 'n' && buf[i] <= 'z'))
	buf[i]=buf[i]-13;
	else if((buf[i]>='A' && buf[i]<='M')||(buf[i]>='a' && buf[i]<='m'))
	buf[i]=buf[i]+13;
    	}
	}
		
	}
	x++;
	if((y=write(1,buf,x)) == -1) // write to stdout. -1 if syscall error
	{
    	    return 1;
	}
	for(i=0;i<100;i++)   		// reseting the buffer 
	{
            buf[i]='\0';}   
	}
	return 0;
}
