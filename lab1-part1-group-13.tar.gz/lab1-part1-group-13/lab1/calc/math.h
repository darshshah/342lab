//Team 13: asp, darshs, ssrisank

#ifndef MATH_H
#define MATH_H

/*
# This file is a Header file. 
# It contains the function prototypes
*/


// Addition function
int add (int x, int y);

// Subtraction function
int sub (int x, int y);

// Multiplication function
int mul (int x, int y);

// Divion function
int div (int x, int y);

// Modulo function
int mod (int x, int y);

#endif
