/*
 * kernel.c: Kernel main (entry) function
 *
 * Author: Group Member 1 <email address>
 *         Group Member 2 <email address>
 * Date:   The current time & date
 */

// make a new .s file in which u can do steps 2-5. This code just wires in the swi
// the argc will go to a3000000-4 = a2fffffc and argv will go to a3000000-8=a2ffffff8
// then the .s file will jump to a200000 where rot13.bin is loaded. 
#include "C_SWI_Handler.h"
#include "exports.h"
extern void swi();
extern void temp();

int main(int argc, char *argv[]) {

	
	unsigned int ptr = 0x5c0009c0; // Don't hardcode this value. Use pointers to derive it from 0x00. 

	*(unsigned int*)ptr =0xe51ff004; // Don't hardcode this value. Use #define. 
	*(unsigned int*)(ptr+4) = (unsigned int)&swi; 

	//void (*functionPtr)(unsigned,unsigned *);
	//functionPtr=&C_SWI_Handler;

	temp();

	return 0;
}
