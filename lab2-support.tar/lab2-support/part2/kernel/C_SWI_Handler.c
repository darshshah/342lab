
void C_SWI_Handler(unsigned swi_no,unsigned *stack_pointer)
{
    unsigned int counter=0;
    char c[100];
    char a;
    unsigned int sp = *(stack_pointer);
    unsigned int fd = *(stack_pointer);
    unsigned int x = *(stack_pointer+2);
    int y = 0;
    char *buffer_pointer = (char *)(*(stack_pointer + 1));

    switch(swi_no)
    {
	case 0x900001:
       	break;
	case 0x900003:
            if (fd != 0)
		{
		    *(stack_pointer) = -9;
		    return; 
		}
	    else if( x > 65535)
		{
		    *(stack_pointer) = -14;
		    return;
		} 
	    else
		{
		    while (counter < x)
		    {
                        
			c[counter++]=getc();

                        if(c[counter-1] == 4)
		        {
			    *(stack_pointer)=counter-1;
			    return;
			} 
			else if((c[counter - 1]==8) || (c[counter - 1] == 127))
			{
			    c[counter-1]='\0';
			    counter--;
			    puts("\b \b");
			    continue;
		        }
			else if((c[counter-1]==10) || (c[counter-1]==13))
			{
			    c[counter-1]='\n';
			    putc('\n');
			    *(stack_pointer)=counter-1;
			    return;
			}	
			else
		        {		
			    putc(c[counter-1]);
		            *(buffer_pointer+(counter-1)) = c[counter-1];

		        }
		    } 
	        }
			
	*(stack_pointer) = counter;
	break;
	case 0x900004:
            if (fd != 1)                                            
            {                                               
                *(stack_pointer) = -9;             
                return;                                 
            }
            else if( x > 65535)                                     
            {                                               
                *(stack_pointer) = -14;            
                return;                                 
            }   
	    else
	    {	
                while(counter < x)
		{
		    a=*(buffer_pointer+counter);
		    putc(a);
		    counter++;
		}
	    }
        putc('\n');
	*(stack_pointer) = counter;   
	break;	
	}
}
