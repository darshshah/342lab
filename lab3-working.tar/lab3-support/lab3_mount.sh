sh sdcard_mount.sh
sudo cp ~/Documents/342_lab/lab3-support/kernel/kernel.bin /media/bootfs/
sudo cp ~/Documents/342_lab/lab3-support/tasks/bin/*.bin /media/bootfs/
sudo cp ~/Documents/342_lab/lab3-support/tasks/hello/package.bin /media/bootfs/
sync
sh umount.sh
sh start_qemu.sh
