/** @file typo.c
 *
 * @brief Echos characters back with timing data.
 *
 * Links to libc.
 */
#include <stdio.h>
#include <unistd.h>

//#include<stdlib.h>
int main(int argc, char** argv)
{
        unsigned long start;
        unsigned long end;
        char input[21];
        //int i;


            printf(">");
            start = time();
            printf("start is %lu", start);
            /*for(i=0;i<20;i++) // i < 1000
            {
                input[i] = getc(stdin);
                if(input[i] == '\0' || input[i] == '\n')
                    break;
            }*/
            read(0, input, 20);
            printf("%s",input);
            end = time();
            printf("%lu s",(end-start)/1000);
         
        return 0;
}
