/** @file hello.c
 *
 * @brief Prints out Hello world using the syscall interface.
 *
 * Links to libc.
 *
 * @author Kartik Subramanian <ksubrama@andrew.cmu.edu>
 * @date   2008-10-29
 */
#include <unistd.h>
#include <stdio.h>
int main(int argc, char** argv)
{
        unsigned long t1;
	const char hello[] = "Hello World";
	write(STDOUT_FILENO, hello, sizeof(hello) - 1);
        
        sleep(4000);
        t1=time();
        printf("the time elasped is %lu\n", t1);
	return 0;
}
