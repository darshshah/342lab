/** @file splat.c
 *
 * @brief Displays a spinning cursor.
 *
 * Links to libc.
 */
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main(int argc, char** argv)
{
	/* Add code here -- put your names at the top. */
        int counter= 0;
        char c;
        while(1)
        {
            switch(counter)
            {
                case 0: c='|';
                break;

                case 1: c='/';
                break;

                case 2: c='-';
                break;

                case 3: c='\\';
                break;

                default: printf("\nThis should never happen!\n");
                return -1;
            }
            counter = (counter + 1) % 4;
            //fflush(stdout);
            printf("%c",c);
            sleep(200);
            //printf("\b \b");
            //system("clear");
        }
	return 0;
}
