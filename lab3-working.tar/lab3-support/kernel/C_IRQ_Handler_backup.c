#include<exports.h>
#include<arm/reg.h>
#include<arm/timer.h>

void C_IRQ_Handler()
{
   // puts("I");
    reg_write(OSTMR_OSSR_ADDR, OSTMR_OIER_E0);
    return;
}
