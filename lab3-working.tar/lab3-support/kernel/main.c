#include <exports.h>

#include <arm/psr.h>
#include <arm/exception.h>
#include <arm/interrupt.h>
#include <arm/timer.h>
#include <arm/reg.h>
#define SWI_FIRST_INST 0xe51ff004

uint32_t global_data;

extern void swi();
extern void irq();
extern void call_user_app(int argc, char *argv[]);

unsigned int inst1,inst2,irq_1,irq_2;
unsigned int r8_save,sp_save,retvalue;
volatile unsigned int global_count;

int kmain(int argc, char** argv, uint32_t table)
{
	app_startup(); /* bss is valid after this point */
	global_data = table;
        global_count = 0;

	/* Add your code here */
	unsigned int offset,ptr,vec,vc_inst;
	unsigned int offset_irq,vec_irq,ptr_irq;
	unsigned int mask=0x041ff000;  //mask has all bits set for LDR
        	
        vec=0x00000008;                 //location of SWI in exception table
	vec_irq=0x00000018;
	vc_inst = (*(unsigned int*)vec);
	if ((vc_inst & mask) != mask)
	{
	   puts("\n Unrecognized Vector table instruction\n");
	   retvalue = 0x0badc0de;
	   return(retvalue);
	}
	else
	{	
	    mask = 0x00800000;         //for checking sign of offset
	    if((vc_inst & mask) == mask)
	    {
  		 //Offset is positive	
	    }
       	    else
	    {
		puts("\n Negative offset\n");
		retvalue = 0x0badc0de;
		return(retvalue);
	    }
	}

        offset = (*(unsigned int*)vec) & 0x00000FFF;  //get the offset
	
        vec = vec + offset + 8;
        ptr = *(unsigned int *)vec;         // get the SWI handler location

        inst1 = *(unsigned int *)ptr;       //save first 2 instr in global vars
        inst2 = *(unsigned int *)(ptr+4);

	*(unsigned int*)ptr = SWI_FIRST_INST;  // replace the first 2 instr
	*(unsigned int*)(ptr+4) = (unsigned int)&swi; 

	offset_irq = (*(unsigned int*)vec_irq) & 0x00000FFF;

	vec_irq = vec_irq + offset_irq + 8;
	ptr_irq = *(unsigned int *)vec_irq;

	irq_1 = *(unsigned int *)ptr_irq;
	irq_2 = *(unsigned int *)(ptr_irq + 4);

	*(unsigned int *)ptr_irq = SWI_FIRST_INST;
	*(unsigned int *)(ptr_irq + 4) = (unsigned int)&irq;

        reg_write(OSTMR_OSCR_ADDR, 0x0);

        reg_set(INT_ICMR_ADDR, 1 << INT_OSTMR_0);
                
        reg_set(INT_ICLR_ADDR, 0 );

        reg_set(OSTMR_OIER_ADDR, OSTMR_OIER_E0);

        reg_write(OSTMR_OSMR_ADDR(0), 0x7EF4);

	call_user_app(argc,argv);    // go to call_user_app code
        
	return(retvalue);   // return with the return value



	return 0;
}
