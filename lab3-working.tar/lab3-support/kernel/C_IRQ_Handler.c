#include<exports.h>
#include<arm/reg.h>
#include<arm/timer.h>
extern volatile unsigned int global_count;

void C_IRQ_Handler()
{
    global_count=global_count+1;
    reg_write(OSTMR_OSSR_ADDR, OSTMR_OIER_E0);
    reg_write(OSTMR_OSMR_ADDR(0), 0x7EF4);
    reg_write(OSTMR_OSCR_ADDR, 0x0);
    return;
}
