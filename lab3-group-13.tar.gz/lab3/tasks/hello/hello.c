/** @file hello.c
 *
 * @brief Prints out Hello world using the syscall interface.
 *
 * Links to libc.
 *
 * @author Kartik Subramanian <ksubrama@andrew.cmu.edu>
 * @date   2008-10-29
 */
#include <unistd.h>
#include <stdio.h>
int main(int argc, char** argv)
{
     	volatile unsigned long t1;
//	int i;
//	const char hello[] = "Hello World";
//	write(STDOUT_FILENO, hello, sizeof(hello) - 1);

	
	sleep(10000);
	t1=time();
	printf("%lu\n",t1);
	

/*
	t1=time();
	printf("%lu",t1);
	sleep(1000);
*/	
	return 0;
}
