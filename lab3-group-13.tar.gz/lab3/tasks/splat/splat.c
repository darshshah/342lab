/** @file splat.c
*
* @brief Displays a spinning cursor.
* Authors: Anish Parikh  <asp@andrew.cmu.edu>
*          Darsh Shah    <darshs@andrew.cmu.edu>
*          Subramanian Srisankaran <ssrisank@andrew.cmu.edu>
*  Date:   9th Nov 1:30 pm

*
* Links to libc.
*/
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main(int argc, char** argv)
{
        int counter= 0;
        // Continue forever
        while(1)
        {
            switch(counter)
            {
                case 0:
		write(1,"|",1);
                break;

                case 1:
		write(1,"/",1);
                break;

                case 2:
		write(1,"-",1);
                break;

                case 3:
		write(1,"\\",1);
                break;

                default: printf("\nThis should never happen!\n");
                return -1;
            }
            // Loop through |,/,- and \.
            counter = (counter + 1) % 4;
            // Wait 200 ms before changing cursor appearance
            sleep(200);
            // Clear the current cursor so as to make it appear spinning
	    write(1,"\b",1);
        }
	return 0;
}
