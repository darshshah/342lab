/** @file typo.c
*
* @brief Echos characters back with timing data.
* Authors: Anish Parikh  <asp@andrew.cmu.edu>
*          Darsh Shah    <darshs@andrew.cmu.edu>
*          Subramanian Srisankaran <ssrisank@andrew.cmu.edu>
*  Date:   9th Nov 1:30 pm
*
* Links to libc.
*/
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#define MAX_SIZE 100

int main(int argc, char** argv)
{
        unsigned long start,end;
        char input[MAX_SIZE];
        char *ptr;
	int time_elapsed,decimal,k,i,ret;
   
	while(1)
	{
	    
            printf("> ");
	    
	    /* Check the time when > appears */
            start = time();
            
            for(k = 0; k < MAX_SIZE ; k++ ) 
            {
	       /* Clear the input buffer */
               input[k]='\0';
            }

	    /* Read the user input */
            ret = read(STDIN_FILENO, input, MAX_SIZE);

	    /* If buffer is full stop taking user input */
	    if(ret == MAX_SIZE)
	    {
            	printf("\n");
	    }
	
	    /* Display the user input */
	    i = write(STDOUT_FILENO, input, MAX_SIZE);

            /* Handle short count in write */
            if ( i < ret )
            {
                ptr = &input[i];
                write(STDOUT_FILENO, ptr , ret - i);
            }

	    /* Get the current timer value */
            end = time();

	    /* Calculate the time elapsed */
	    time_elapsed = (end-start) / 100;
	    decimal = time_elapsed % 10;
	    time_elapsed = time_elapsed / 10;

            printf("\n%d.%d seconds\n",time_elapsed,decimal);
	    
        } 
        return 0;
}
