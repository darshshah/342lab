/* Cricket user application - play a simulated cricket game
* Authors: Anish Parikh  <asp@andrew.cmu.edu>
*          Darsh Shah    <darshs@andrew.cmu.edu>
*          Subramanian Srisankaran <ssrisank@andrew.cmu.edu>
*  Date:   11th Oct 1:30 pm
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

#define reset 0
#define set 1
#define impossible 29000
#define reaction 1000
#define sleep_time 100
#define mod_value 10

int overs = 2;
int wickets = 2;

void scorecard(int, int, int, int);
void superover(char*, char*, int);
void check_weather(int);
int check_retired(int);
void duck_worth_lewis(int, int, int, int, char*, char*, int);
int give_random();
int play(char*, char*, int, int, int, int);

void main()
{
    while(1)
    {
        int my_team,opp_team,flag=reset, toss = -1 , order = -1, my_score=0 ,
        opp_score=0 ,ret;
	char input[1];
	input[0] = '\0';
	// List of teams
        char teams[8][12]= { "Australia", "India", "SouthAfrica", "England" ,
        "SriLanka", "WestIndies" , "Pakistan" , "NewZealand" };
	// Selecting our team	
	while(flag!=set)
	{
            printf("\nPick your team: 1. Australia 2. India 3. South Africa 4."
            "England 5. Sri Lanka 6. West Indies 7. Pakistan 8. New Zealand:");
	    ret = read(0, input, 1);
	    my_team = input[0] - 48;
	    if(my_team>0 && my_team<9)
	    {
		flag = set;
	        my_team -= 1;
	    }
	}
	flag = reset;
	// Selecting opponent team
	while(flag!=set)
	{
                printf("\n Pick your opponent: 1. Australia 2. India 3. South"
                "Africa 4. England 5. Sri Lanka 6. West Indies 7. Pakistan 8."
                " New Zealand:");
		ret = read(0, input, 1);
		opp_team = input[0] - 48;
		if(opp_team>0 && opp_team<9 && opp_team != (my_team + 1))
		{
	            flag = set;
		    opp_team -= 1;
		}
	}
	// Check weather conditions before play starts
	check_weather(50);
	printf("\n Match: %s vs %s",teams[my_team],teams[opp_team]);
	flag = reset;
	// Put toss
	while(flag !=set)
	{
		printf("\n Call the toss: Heads(1) or Tails(0):");
		ret = read(0, input, 1);
		toss = input[0] - 48;
		toss %= 2;
		if(toss == 0 || toss == 1)
		{
			flag = set;
		}
	}
	flag = reset;
	// Selecting who bats and who fields 
	if ( ((time()/10) % 2) == (unsigned int)toss)
	{
		while(flag != set)
		{
			printf("\n Great! You won the toss! Do you want to bat"
                        "(0) or field(1)?");
			ret = read(0, input, 1);
			order = input[0] - 48;
			order %= 2;
			if(order == 0 || order == 1)
			{
				flag = set;	
				if(order == 0)
                                        printf("\n %s chose to bat!\n",
                                        teams[my_team]);
				else
                                        printf("\n %s chose to field!\n",
                                        teams[my_team]);
			}
		}
	}
	else
	{
		printf("\n You lost the toss!\n");
		order = (time()/10) % 2;
		if(order == 0)
			printf("\n %s chose to field!\n", teams[opp_team]);
		else
			printf("\n %s chose to bat!\n", teams[opp_team]);
	}
	flag = reset;
	int x = 0;
	int target = impossible;
	// Play two innings
	while(x < 2)
	{
		if (order == 0)
		{
                        my_score = play(teams[my_team],teams[opp_team], order,
                        overs, wickets, target);
			target = my_score;
		}
		else
		{
                        opp_score = play(teams[my_team],teams[opp_team], order,
                        overs, wickets, target);
			target = opp_score;
		}
		x++;
		order = (order == 0)? 1 : 0;
	}
	// Declaring winner
	if(my_score > opp_score)
	{
		printf("\n Congratulations! %s won!\n", teams[my_team]);
	}
	else if(my_score < opp_score)
	{
		printf("\n Sorry! You lost! %s won!\n", teams[opp_team]);
	}
	// Match tied and hence super over is bowled
	else
	{
		order = (order == 0)? 1 : 0;
		superover(teams[my_team],teams[opp_team],order);
	}
    }    
}

// Function to display scorecard
void scorecard(int runs, int wickets_fallen, int balls, int target)
{
	int overs_bowled = balls/6;
        printf("\n SCORECARD: Runs: %d Wickets: %d Overs : %d \n",runs,
        wickets_fallen, overs_bowled);
	if(target != impossible)
		printf("Target: %d\n", target + 1);
}

// Function to play superover
void superover(char my_team[12], char opp_team[12], int order)
{
	int flag = reset;
	int my_score = -1, opp_score = -1;
	int target = impossible;
	while( flag != set )
	{
            printf("\nExciting! Since the scores are tied, we are going to"
            "have a super over!\n");
	    int x = 0;
	    while(x < 2)
	    {
	        if (order == 0)
	        {
	            my_score = play(my_team,opp_team, order, 1, 3, target);
	            target = my_score;
		}
	        else
	        {
	            opp_score = play(my_team,opp_team, order, 1, 3, target);
	            target = opp_score;
	    	}
		x++;
		order = (order == 0)? 1 : 0;
	    }
	    if(my_score != opp_score)
	        flag = set;
		// Continue super over until match ends
	    else
	    {
		printf("\nWow! Tied again! We're in for another superover!\n");
		check_weather(46);
	    }
	}	
	// Declaring winner
	if(my_score > opp_score)
	{
		printf("\n Congratulations! %s won!\n", my_team);
	}
	else if(my_score < opp_score)
	{
		printf("\n Sorry! You lost! %s won!\n", opp_team);
	}
}

int play(char *my_team, char *opp_team, int order, int overs, int wickets, int
target)
{
	printf("\n The inning is about to begin!\n");
	int runs = 0;
	int wickets_fallen = 0;
	int balls_bowled = 0;
	int balls = overs * 6, ret;
	check_weather(33);
	if(order == 0)
	{
		printf("\n %s about to bat!", my_team);
                printf("\n RULES : 1. You have %d wickets and %d overs\n",
                wickets, overs);
                printf("\n 2. Everytime you see PLAY, press a number between 0"
                "to 6 as soon as possible!\n");
                printf("\n 3. If you delay pressing the number or press an"
                "invalid number, you lose a wicket!\n");
		printf("\n Good Luck!\n");
	}
	if(order == 1)
	{
		printf("\n%s about to bowl!", my_team);
                printf("\nRULES : 1. You have %d overs to try to finish off %d"
                "wickets\n",overs,wickets);
                printf("\n2. Everytime you see PLAY, press a number between 0"
                "to 6 as soon as possible!\n");
                printf("\n 3. If you delay pressing the number or press an"
                "invalid number, you concede a six off a no ball!\n");
		printf("\n Good Luck!\n");
	}
	// Loop until innings is over
        while(wickets_fallen < wickets && balls_bowled < balls && runs <=
            target)
	{
		printf("\n Press any key to continue\n");
		char wait[1];
		wait[0] = '\0';
		read(0,wait,1);
		char input[1];
		input[0] = '\0';
		printf("\n Get ready for ball number : %d!", (balls_bowled+1));
		sleep(sleep_time);
		// Check if the batsmen got retired hurt
		int retired = check_retired(234);
		if(retired == set)
		{
			wickets_fallen++;
			continue;
		}
		int num=0;
		// Check if weather is fine
		check_weather(859);
		if( target != impossible && balls_bowled > (balls/2) )
		{
                        // Decide based on duckworth lewis if this is second
                        // innings and more than half the inning is over
                        duck_worth_lewis(200, runs, balls_bowled, target,
                        my_team, opp_team, order);
		}
		int random = give_random();
		sleep( random * random * 100 );
                printf("\n Press a number between 0 to 6 and press Enter!"
                "Soon!!\n PLAY:");
		int time1 = time();
		ret = read(0, input, 1);
		num = input[0] - 48;
		int time2 = time();
		// Check for invalid input
		if( (num < 0) || (num > 6) )
		{
			printf("\n Invalid key!\n");
			if(order == 0)
			{
                                printf("\nYou were waving to the audience when"
                                "the ball was delivered! You lost a wicket!"
                                " Lame batting!\n");
				wickets_fallen++; 
				balls_bowled++;
				if(balls_bowled % 6 == 0 && balls_bowled > 0)
				{
                                        scorecard(runs, wickets_fallen,
                                        balls_bowled, target);
				}
			}
			else if(order == 1)
			{
                                printf("\nYou conceded a 6 off a no-ball! Lame"
                                "bowling! \n");
				runs += 7;
			}
			continue;
		}
		num = (num + give_random()) % 7;
		// Declare the ball a no-ball once in a while
		if( (num == give_random()) && (give_random() == 5) )
		{
			printf("\n It is a no ball!\n");
			printf("\n %d runs scored off this ball!\n",num);
			runs = runs + num + 1;
			continue;
		}
		// Check for late reaction
		if( (time2 - time1) > reaction)
		{
			if(order == 0)
			{
				printf("\n Late reaction! Wicket lost!\n");
				wickets_fallen++; 
				balls_bowled++;
			}
			else if(order == 1)
			{
				printf("\n Late reaction!");
				printf("\n You conceded a 4 off a wide! \n");
				runs += 5;
			}
			continue;
		}
		// If num = 0, decide whether it is out or a dot
		else if( num == 0 )
		{
			if( give_random() > 4 )
			{
                                printf("\nNo runs scored off this ball! Good"
                                "bowling!\n");
				balls_bowled++;
			}
			else
			{
				printf("\n Wicket! Caught!\n");
				wickets_fallen++; 
				balls_bowled++;
			}
		}
		// Check for an occassional LBW
		else if( give_random() == 0 && give_random() == 1)
		{
			if(balls_bowled % 2 == 0)
			{
				printf("\n Wicket! LBW!\n");
				wickets_fallen++; 
				balls_bowled++;
			}	
			else
			{
				printf("\n Wicket! Run out!\n");
				if(num > 0)
                                    num--;
				num = (num>2)? 2 : num;
				printf("\n %d runs were scored though!\n",num);
				runs+=num;
				wickets_fallen++; 
				balls_bowled++;
			}
		}
		// Make 3, 5 and 6 less frequent
		else if( (num == 3) || (num>4) )
		{
			if(num == 3)
			{
				if (give_random() < 4)
					num = 3;
				else
					num = 2;
			}
			else if(num == 5)
			{
				if( give_random() < 2 )
					num = 5;
				else
					num = 1;
			}
			else if(num == 6)
			{
				if( give_random() < 3 )
					num = 6;
				else
					num = 4;
			}
			printf("\n %d runs scored off this ball!\n",num);
			runs += num;
			balls_bowled++;
		}
		else
		{
                        if (num < 0)
                        {
                            num = (num * (-1)) % 7;
                        }
			printf("\n %d runs scored off this ball!\n",num);
			runs += num;
			balls_bowled++;
		}
		// Display scorecard at the end of each over
		if(balls_bowled % 6 == 0 && balls_bowled > 0)
		{
			scorecard(runs, wickets_fallen, balls_bowled, target);
		}
	}
	// Declare winner
	if(runs > target)
	{
		printf("\n The game has ended! Target achieved! \n");
		return (impossible+1);
	}
	if(wickets_fallen == wickets)
	{
		printf("\n All out!\n");
                printf("\n Total score at the end of the innings is:"
                "%d\n",runs);
	}
	else if(balls_bowled == balls)
	{
		printf("\n The innings is over!\n");
                printf("\n Total score at the end of the innings is:"
                "%d\n",runs);
	}
	return runs;
    
}

// Function to check if weather conditions are fine
void check_weather(int num)
{
	if( (time()/10) % num == 0 )
	{
                printf("\n Oh No! The match has been cancelled due to bad"
                "weather! We're sorry! \n");
		exit(1);
	}
}

// Function to check if the batsmen is retired
int check_retired(int num)
{
	if( (time()/10) % num == 0 )
	{
                printf("\n One of the batsmen has been injured! He cannot"
                "continue anymore! One wicket lost! \n");
		return 1;
	}
	return 0;
}

// Function to generate a random number between 0 and 6
int give_random()
{
	static int make_it_rand = 0;
	int rand_mod = (time()/10) % mod_value;
	int rand = (((time()/10) % mod_value) * rand_mod) + make_it_rand;
	make_it_rand = ( make_it_rand + 1 ) % 5000;
	return (rand % 7);
}

// Function to declare winner based on duckworth lewis
void duck_worth_lewis(int num, int runs, int balls, int target, char
my_team[12], char opp_team[12], int order)
{
	if( (time()/10) % num == 0)
	{
		printf("\n The match has been interrupted due to rain!\n");
                printf("\n The result has been announced using the Duckworth"
                "Lewis method\n");
		// Declare winner based on run rate of both teams
		if( (target / (6 * overs)) > (runs/balls) )
		{
			if(order == 0)
			{
                            printf("\n Sorry! %s lost and %s"
                            "won!\n",my_team, opp_team);
			    exit(2);
			}
			else if(order == 1)
			{
                            printf("\n Congratulations! %s won!\n",my_team);
			    exit(2);
			}
		}
		else if((target / (6 * overs)) < (runs/balls) )
		{
			if(order == 0)
			{
			    printf("\n Congratulations! %s won!\n",my_team);
			    exit(2);
			}
			else if(order == 1)
			{
                            printf("\n Sorry! %s lost and %s won!\n",my_team,
                            opp_team);
			    exit(2);
			}
		}
		// Declare a tie based on run rate according to duckworth lewis
		else
		{
                        printf("\n The match has been declared a tie and the"
                        "points have been shared!\n");
			exit(2);
		}
	}
}


