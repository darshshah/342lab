/*
* C_SWI_Handler.c: Interrupt Handler
*
* Author: Anish Parikh(asp@andrew.cmu.edu)
*         Darsh Shah(darshs@andrew.cmu.edu)
*         Subramanian Srisankaran(ssrisank@andrew.cmu.edu)   
*         
* Date:   25th October,2013 6:00 PM
*/


/* Our interpretation of read/write conditions:
*  When we do a read syscall, the buffer can't be uboot code,
*  uboot global data struct or abort stack.
*  We also assume that an address range from 0x00 to 0xff is 
*  writable with 0x00 and 0xff inclusive.
*/
#include<exports.h>
#include<arm/reg.h>
#include<arm/timer.h>
#include<arm/interrupt.h>
#include<bits/swi.h>
#include<bits/errno.h>

#define BUF_SIZE 100
#define SWI_OFFSET 0x00000008
#define IRQ_OFFSET 0x00000018
#define OFFSET_MASK 0x00000FFF

extern void sys_exit();
extern unsigned int inst1;
extern unsigned int inst2;
extern unsigned int irq_1;
extern unsigned int irq_2;
extern unsigned int retvalue;
extern volatile unsigned int global_count;

void C_SWI_Handler(unsigned swi_no,unsigned *stack_pointer)
{
    unsigned int counter=0, vec, offset, ptr ;
    char c[BUF_SIZE];                            //Buffer size
    char a;
    unsigned int fd = *(stack_pointer);     //file descriptor (argv[1])
    unsigned int x = *(stack_pointer+2);    //count (argv[3])
    char *buffer_pointer = (char *)(*(stack_pointer + 1));  //array (argv[2])
    unsigned int sleep_val=0;
    unsigned int val=0;
    
    switch(swi_no)
    {
	case EXIT_SWI:                      // exit
        vec = SWI_OFFSET;
        offset = (*(unsigned int*)vec) & OFFSET_MASK;
        vec = vec + offset + 8;
        ptr = *(unsigned int *)vec;         // ptr has addr of original swi
        *(unsigned int*)ptr=inst1;          // restore original inst 1
        *(unsigned int*)(ptr+4)=inst2;      // restore original inst 2

        vec = IRQ_OFFSET;
        offset = (*(unsigned int*)vec) & OFFSET_MASK;
        vec = vec + offset + 8;
        ptr = *(unsigned int *)vec;         // ptr has addr of original swi
        *(unsigned int*)ptr=irq_1;          // restore original inst 1
        *(unsigned int*)(ptr+4)=irq_2;      // restore original inst 2


        sys_exit();                         // go to sys_exit.s
       	break;
	
        case READ_SWI:                      //read
            if (fd != 0)
		{
		    *(stack_pointer) = -(EBADF);  //-EBADF
		    return; 
		}
	    else if((buffer_pointer<(char*)0xa0000000 || 
                   buffer_pointer> (char*)0xa3ffffff) ||
                   (buffer_pointer<=(char*)0xa3ffffff && 
                   (buffer_pointer+x)>(char*)0xa3ffffff))
		{
		    *(stack_pointer) = -(EFAULT); //-EFAULT
		    return;
                }
            else if((buffer_pointer>=(char*)0xa3f00000 && 
                   buffer_pointer<=(char*)0xa3ffffff) || 
                   (buffer_pointer<(char*)0xa3f00000 &&
                   (buffer_pointer+x)>=(char*)0xa3f00000) || 
                   (buffer_pointer>=(char*)0xa3ededf4 && 
                   buffer_pointer<=(char*)0xa3edefff) || 
                   (buffer_pointer<(char*)0xa3ededf4 &&
                   (buffer_pointer+x)>=(char*)0xa3ededf4))
                {
                    *(stack_pointer) = -(EFAULT); //_EFAULT
                    return;
                }
	    else            //The below code will check all the conditions
		{
		    while (counter < x)
		    {
			c[counter]=getc();
                        if(c[counter] == 4)
		        {
                            putc('\n');
			    *(buffer_pointer) = '\0';
			    *(stack_pointer)=counter;
			    return;
			} 
			else if((c[counter] == 127))
			{   
                            if(counter != 0)
                            {
                                counter--;
                                *(buffer_pointer+(counter))='\0';
                                puts("\b \b");
                            }
			    continue;
		        }
			else if((c[counter]==10) || (c[counter]==13))
			{
			    c[counter]='\n';
			    putc('\n');
			    *(stack_pointer)=counter;
			    return;
			}	
			else
		        {		
			    putc(c[counter]);
		            *(buffer_pointer+(counter)) = c[counter];

		        }
                        counter++;  
		    } 
	        }
			
	*(stack_pointer) = counter;
	break;
	
        case WRITE_SWI:                          // write
            if (fd != 1)                                            
            {                                               
                *(stack_pointer) = -9;          // -EBADF             
                return;                                 
            }
            else if(((buffer_pointer<(char*)0x00000000 || 
                   buffer_pointer>(char*)0x00ffffff) || 
                   (buffer_pointer+x)>(char*)0x00ffffff) && 
                   ((buffer_pointer<(char*)0xa0000000 || 
                   buffer_pointer>(char*)0xa3ffffff) ||
                   (buffer_pointer+x)>(char*)0xa3ffffff))
            {                                               
                *(stack_pointer) = -14;         // -EFAULT            
                return;                                 
            }   
	    else
	    {	
                while(counter < x)
		{
		    a=*(buffer_pointer+counter);
		    putc(a);
		    counter++;
		}
	    }
       
	*(stack_pointer) = counter;   
	break;	
        
        case TIME_SWI:
	
	*(stack_pointer) = (global_count)*10;
        break;
         
        case SLEEP_SWI:  //sleep
        
	val = (*(stack_pointer))/10;
        sleep_val = val + global_count;
        while (global_count<sleep_val);
        
        break;

        default:                                // Default case is to exit 
            puts("\nInvalid SWI number\n");
            retvalue = 0x0badc0de;
            sys_exit();
            break;
	}
}
