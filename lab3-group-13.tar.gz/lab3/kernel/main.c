/*Authors: Anish Parikh  <asp@andrew.cmu.edu>
*          Darsh Shah    <darshs@andrew.cmu.edu>
*          Subramanian Srisankaran <ssrisank@andrew.cmu.edu>
*  Date:   9th Nov 1:30 pm
*  main.c is the main kernel file. This file will set will wire in swi and irq
*  and set up the timer interrupt.
*/

#include <exports.h>
#include <arm/psr.h>
#include <arm/exception.h>
#include <arm/interrupt.h>
#include <arm/timer.h>
#include <arm/reg.h>

#define HANDLER_FIRST_INST 0xe51ff004
#define SWI_OFFSET 0x00000008
#define IRQ_OFFSET 0x00000018
#define LDR_MASK 0x041ff000
#define OFFSET_SIGN_MASK 0x00800000
#define OSMR_VALUE 0X7EF4
#define OFFSET_MASK 0x00000FFF
#define INVALID_INSTR 0x0badc0de

uint32_t global_data;

extern void swi();
extern void irq();
extern void call_user_app(int argc, char *argv[]);
extern void load_irq_stack();

void install_swi_handler(unsigned int);
void install_irq_handler(unsigned int);
void init_timer();
void enable_interrupts();
void disable_interrupts();

unsigned int inst1,inst2,irq_1,irq_2;
unsigned int r8_save,sp_save,retvalue,cpsr_save;
volatile unsigned int global_count;

int kmain(int argc, char** argv, uint32_t table)
{
	app_startup(); /* bss is valid after this point */
	global_data = table;

	/* Add your code here */
	
	/*Initialize global count variable */
        global_count = 0;

	unsigned int vec,vec_irq,vc_inst;
	unsigned int mask = LDR_MASK;  //mask has all bits set for LDR
        	
	/* Load the offset of SWI and IRQ in the vector table */
        vec= SWI_OFFSET;                 
	vec_irq= IRQ_OFFSET;

	/*Check if instruction at SWI_OFFSET is LDR instruction */
	vc_inst = (*(unsigned int*)vec);
	if ((vc_inst & mask) != mask)
	{
	   puts("\n Unrecognized Vector table instruction\n");
	   retvalue = INVALID_INSTR;
	   return(retvalue);
	}
	else
	{	
	    mask = OFFSET_SIGN_MASK;         //for checking sign of offset
	    if((vc_inst & mask) == mask)
	    {
  		 //Offset is positive	
	    }
       	    else
	    {
		puts("\n Negative offset\n");
		retvalue = INVALID_INSTR;
		return(retvalue);
	    }
	}

	/* Wire in SWI Handler */
	install_swi_handler(vec);

	/* Wire in IRQ handler */
	install_irq_handler(vec_irq);

	/* Set up IRQ stack */
	load_irq_stack();

	/* Initialize registers for timer */
	init_timer();

	/* Enable IRQ's */
	enable_interrupts();

	/* Jump to user application */
	call_user_app(argc,argv);    
 	
	/* Disable IRQ's */       
	disable_interrupts();	

	return(retvalue);   // return with the return value

}


/* Function for wiring in our SWI Handler */
void install_swi_handler(unsigned int vec)
{

	unsigned int offset,ptr;

	/* Get the offset */
	offset = (*(unsigned int*)vec) & OFFSET_MASK;  

	/* Get the SWI Handler location */
	vec = vec + offset + 8;
        ptr = *(unsigned int *)vec;         

	/* Save the original first two instructions */
        inst1 = *(unsigned int *)ptr;       
        inst2 = *(unsigned int *)(ptr+4);

	/* Replace the first two instructions with our instructions */
        *(unsigned int*)ptr = HANDLER_FIRST_INST;  
        *(unsigned int*)(ptr+4) = (unsigned int)&swi;

}

/* Function for wiring in our IRQ handler */
void install_irq_handler(unsigned int vec_irq)
{

	unsigned int offset_irq,ptr_irq;	

	/* Get the offset */
	offset_irq = (*(unsigned int*)vec_irq) & OFFSET_MASK;

	/* Get the IRQ Handler location */
        vec_irq = vec_irq + offset_irq + 8;
        ptr_irq = *(unsigned int *)vec_irq;

	/* Save the original first two instructions */
        irq_1 = *(unsigned int *)ptr_irq;
        irq_2 = *(unsigned int *)(ptr_irq + 4);

	/* Replace with our instructions */
        *(unsigned int *)ptr_irq = HANDLER_FIRST_INST;
        *(unsigned int *)(ptr_irq + 4) = (unsigned int)&irq;
}

/* Function for initializing the registers for the timer */
void init_timer()
{
        /* Set the OSCR to 0 */
	reg_write(OSTMR_OSCR_ADDR, 0x0);

	/* Enable interrupts for OS Timer Match Register 0 */ 
        reg_set(INT_ICMR_ADDR, 1 << INT_OSTMR_0);

	/* Set interrupt type to IRQ for OSTMR*/
        reg_set(INT_ICLR_ADDR, 0 );

	/* Will enable OSSR to be set when OSCR = OSMR(0)*/
        reg_set(OSTMR_OIER_ADDR, OSTMR_OIER_E0);

	/* Load the value in OSMR(0) for which interrupt should occur*/
        reg_write(OSTMR_OSMR_ADDR(0), OSMR_VALUE);

}

/* Enable IRQ's by setting the IRQ bit in CPSR to 0 */
void enable_interrupts()
{
	volatile uint32_t get_cpsr=0;

	/*Obtain the value of cpsr */
	get_cpsr = read_cpsr();
	
	/* Mask the cpsr to set IRQ bit to 0 */
        get_cpsr &= ~(PSR_IRQ);

	/* Overwrite the cpsr with the updated value */
        write_cpsr(get_cpsr);
}

/* Disable IRQ's by setting the IRQ bit in cpsr to 1 */
void disable_interrupts()
{

	volatile uint32_t _cpsr=0;
	
	/* Obtain the current value of cpsr */
	_cpsr=read_cpsr();
	
	/* Mask the cpsr to set IRQ bit to 1 */
        _cpsr |= (PSR_IRQ);

	/* Overwrite the cpsr with the updated value */
        write_cpsr(_cpsr);
}

