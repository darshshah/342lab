/* Authors: Anish Parikh  <asp@andrew.cmu.edu>
*          Darsh Shah    <darshs@andrew.cmu.edu>
*          Subramanian Srisankaran <ssrisank@andrew.cmu.edu>
*  Date:   9th Nov 1:30 pm
*/

/*
This is the IRQ Handler which checks whether the received interrupt is from
the timer and then updates the global count variable when an IRQ is called
and also reloads the values of the appropriate registers.
*/


#include<exports.h>
#include<arm/reg.h>
#include<arm/timer.h>
#include<arm/interrupt.h>

#define OSMR_VALUE 0x7EF4

extern volatile unsigned int global_count;

void C_IRQ_Handler()
{
    /* Check if recieved IRQ is from the timer */
    if((reg_read(INT_ICPR_ADDR)) & (1 << INT_OSTMR_0))
    {
    /*Update the global count variable */
    global_count=global_count+1;

    /* Write 1 in OSSR */
    reg_write(OSTMR_OSSR_ADDR, OSTMR_OIER_E0);
   
    /* Reload the value of OSMR */
    reg_write(OSTMR_OSMR_ADDR(0), OSMR_VALUE);

    /* Reload the value of OSCR to 0 */
    reg_write(OSTMR_OSCR_ADDR, 0x0);
    }
    
}
