/*
 * kernel.c: Kernel main (entry) function
 *
 * Author: Anish Parikh(asp@andrew.cmu.edu)
 *         Darsh Shah(darshs@andrew.cmu.edu)
 *         Subramanian Srisankaran(ssrisank@andrew.cmu.edu)   
 *         
 * Date:   25th October,2013 6:00 PM
 */
// Logic:
// call_user_app.S file will handle steps 2-5. This code wires in the swi
// the argc will go to a3000000-4 = a2fffffc and argv  to a3000000-8=a2ffffff8
// then the .S file will jump to a200000 where rot13.bin is loaded. 
#define SWI_FIRST_INST 0xe51ff004
#include<exports.h>
extern void swi();
extern void call_user_app(int argc, char *argv[]);
unsigned int inst1;
unsigned int inst2;
unsigned int r8_save;
unsigned int sp_save;
unsigned int retvalue;

int main(int argc, char *argv[]) {
        unsigned int offset,ptr,vec,vc_inst;
	unsigned int mask=0x041ff000;  //mask has all bits set for LDR
	
        vec=0x00000008;                 //location of SWI in exception table
	vc_inst = (*(unsigned int*)vec);
	if ((vc_inst & mask) != mask)
	{
	   puts("\n Unrecognized Vector table instruction\n");
	   retvalue = 0x0badc0de;
	   return(retvalue);
	}
	else
	{	
	    mask = 0x00800000;         //for checking sign of offset
	    if((vc_inst & mask) == mask)
	    {
  		 //Offset is positive	
	    }
       	    else
	    {
		puts("\n Negative offset\n");
		retvalue = 0x0badc0de;
		return(retvalue);
	    }
	}

        offset = (*(unsigned int*)vec) & 0x00000FFF;  //get the offset
	
        vec = vec + offset + 8;
        ptr = *(unsigned int *)vec;         // get the SWI handler location

        inst1 = *(unsigned int *)ptr;       //save first 2 instr in global vars
        inst2 = *(unsigned int *)(ptr+4);

	*(unsigned int*)ptr = SWI_FIRST_INST;  // replace the first 2 instr
	*(unsigned int*)(ptr+4) = (unsigned int)&swi; 

	call_user_app(argc,argv);    // go to call_user_app code
        
	return(retvalue);   // return with the return value
}
